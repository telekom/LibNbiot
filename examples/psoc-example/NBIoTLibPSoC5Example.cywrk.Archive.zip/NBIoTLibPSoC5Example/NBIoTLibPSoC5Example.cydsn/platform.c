/* ========================================================================
 * File Name: platform.c
 *
 * Author: Edgar Hindemith
 *
 * Copyright (C) 2016,2018, Ingenieurbuero Edgar Hindemith, 
 * T-Systems International GmbH
 * contact: libnbiot@t-systems.com, opensource@telekom.de
 *
 * This file is distributed under the conditions of the Apache License,
 * Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * For details see the file LICENSE at the toplevel.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================================
*/

#include "libnbiot.h"
#include "led.h"
#include "nbiot_time.h"
/* ------------------------------------------------------------- */
/* include "usb_com.h" only if usb-serial is used for monitoring */
#include "usb_com.h"
/* ------------------------------------------------------------- */
#include "platform.h"

uint8 hibernateInProgress = 0;

CY_ISR(wakeupHandler)
{ 
    /* read status to clear interrupt register */
    SleepTimer_1_GetStatus();
}

CY_ISR(buttonHandler)
{
    Pin_3_ClearInterrupt();
    if(!hibernateInProgress)
    {
        hibernateInProgress = 1;
    }
    else
    {
        hibernateInProgress = 0;
    }
}

ReadStatus readStatus()
{
    uint8 status = UART_1_ReadRxStatus();
    ReadStatus rs = rx_empty;
    if(0 != (status & UART_1_RX_STS_FIFO_NOTEMPTY))
    {
        rs = rx_avail;
    }
    if(0 != (status & (UART_1_RX_STS_BREAK | UART_1_RX_STS_PAR_ERROR |
                            UART_1_RX_STS_STOP_ERROR | UART_1_RX_STS_OVERRUN)))
    {
        if(rx_empty == rs)
        {
            rs = rx_error;
        }
        else
        {
            rs = rx_availwitherror;
        }
    }
    return rs;
}


WriteStatus writeStatus()
{
    uint8 bytes = UART_1_GetTxBufferSize();
    WriteStatus ws = tx_full;
    if(0 == bytes)
    {
        ws = tx_empty;
    }
    else if(1 == bytes)
    {
        ws = tx_hasBytes;
    }
    return ws;
}


void componentsStartEx()
{
    SleepTimer_1_Start();
    isr_2_StartEx(wakeupHandler);
    
    Pin_3_ClearInterrupt();
    isr_3_StartEx(buttonHandler);
    
    /* ------------------------------------------- */
    /* place additional component-start calls here */
    
    /* ------------------------------------------- */
}

void componentsStart()
{
    /* start additional components */
    componentsStartEx();
    /* Enabling the UART */
    UART_1_Start();     
#ifdef USBFS_DEVICE
    /* start monitoring via USB */
    startUsb();
#endif
    /* init the timer-ISR */
    startNbiotTimer();
}

void componentsSleepEx()
{
#ifdef USBFS_DEVICE
    usbSleep();
#endif
    /* ------------------------------------------- */
    /* place additional component-sleep calls here */
    
    /* ------------------------------------------- */
}

void componentsSleep()
{
    componentsSleepEx();
    /* set the UART and the timer to sleep */
    UART_1_Sleep();
    Timer_1_Sleep();
    Timer_1_ReadStatusRegister();
}

void componentsWakeupEx()
{
    /* -------------------------------------------- */
    /* place additional component-wakeup calls here */
    
    /* -------------------------------------------- */
#ifdef USBFS_DEVICE
    usbWakeup();
#endif
}

void componentsWakeup()
{
    /* wake up the components */
    Timer_1_Wakeup();
    UART_1_Wakeup();
    componentsWakeupEx();
}

void psocSleep(uint32 seconds, uint8 rtcAvail)
{
    uint32 millisUpdate = 0;
    #if( HAS_MODEM_RTC )
    time_t t = 0;
    #endif

    componentsSleep();   
    /* switch off the light */
    ledOff();
    /* read status to clear interrupt register */
    CyPmReadStatus(CY_PM_CTW_INT);
    do
    {
        /* save the clock-settings before sleep */
        CyPmSaveClocks();
        /* set CPU to sleep */
        CyPmSleep(PM_SLEEP_TIME_NONE, PM_SLEEP_SRC_CTW);
        /* read status to clear interrupt register */
        CyPmReadStatus(CY_PM_CTW_INT);
        /* restore the clock-settings */
        CyPmRestoreClocks();
        /* add the missed milliseconds */
        millisUpdate += MILLIS_SLEEP_UPDATE;
    } while (--seconds);
    /* 
    blue light
    what does it do?
    it shines blue
    */
    ledOn();

    componentsWakeup();
    /* 
    Synchronize the time after sleep.
    If RTC is not available (modem switched off), the
    time will be updated with the missed milliseconds.
    The ILO of the sleep-timer has a very poor accuracy,
    therefor a sync to modem-RTC will be necessary after
    modem wakeup
    */
    #if( HAS_MODEM_RTC )
    if(rtcAvail)
    {
        t = getModemTime();
        setTime(t);
    }
    else 
    #else
    (void)rtcAvail;
    #endif    
    {
        updateMillis(millisUpdate);
    }
}

void fakedSleep(uint32 s)
{
    unsigned long long seconds = (unsigned long long)s << 2;

    do
    {
        /* blinking with 2Hz */
        ledToggle();
        CyDelay(250);
    } while (--seconds);
}

void platformSleep(uint32 seconds, uint8 rtcAvail)
{
#ifdef USBFS_DEVICE        
    #ifdef LINUX_HOST
        psocSleep(seconds, rtcAvail);
    #else
        (void)rtcAvail;
        fakedSleep(seconds);
    #endif
#else
    psocSleep(seconds, rtcAvail);
#endif
}

void psocHibernate()
{
    #if( HAS_MODEM_RTC )
    time_t t = 0;
    #endif
    uint8 modemOn = 0;

    if(NBIOT_HIBERNATE_STATE != getNbiotState())
    {
        modemOn = 1;
        nbiotHibernate(0);
    }
    
    componentsSleep();   
    /* switch off the light */
    ledOff();

    /* clear interrupt register */
    Pin_3_ClearInterrupt();
    /* save the clock-settings before sleep */
    CyPmSaveClocks();
    
    /* unlock SPC if locked by DieTemp */
    int16 dummy;
    while(CYRET_STARTED == DieTemp_1_Query(&dummy))
    {
        CyDelay(1);
    }
    
    /* set CPU to hibernate */
    CyPmHibernate();//Ex(CY_PM_HIB_SRC_COMPARATOR0);

    /* clear interrupt register */
    Pin_3_ClearInterrupt();
    /* restore the clock-settings */
    CyPmRestoreClocks();

    /* 
    blue light
    what does it do?
    it shines blue
    */
    ledOn();

    componentsWakeup();

    if(modemOn)
    {
        nbiotWakeup();
    }
    /* 
    Synchronize the time after sleep.
    */
    #if( HAS_MODEM_RTC )
    t = getModemTime();
    setTime(t);
    #endif
}

void fakedHibernate()
{
    uint8 modemOn = 0;
    if(NBIOT_HIBERNATE_STATE != getNbiotState())
    {
        modemOn = 1;
        nbiotHibernate(0);
    }
    do
    {
        /* blinking with 0.5Hz */
        ledToggle();
        CyDelay(1000);
        ledToggle();
        CyDelay(1000);
    } while (hibernateInProgress);
    if(modemOn)
    {
        nbiotWakeup();
    }
}

void fakeHibernateBySleep()
{
    uint8 modemOn = 0;
    if(NBIOT_HIBERNATE_STATE != getNbiotState())
    {
        modemOn = 1;
        nbiotHibernate(0);
    }
    #if( HAS_MODEM_RTC )
    time_t t = 0;
    #endif

    componentsSleep();   
    /* switch off the light */
    ledOff();
    /* read status to clear interrupt register */
    CyPmReadStatus(CY_PM_CTW_INT);
    
    /* perform a real sleep but blink with 1Hz and ~95% off */
    do
    {
        /* save the clock-settings before sleep */
        CyPmSaveClocks();
        /* set CPU to sleep */
        CyPmSleep(PM_SLEEP_TIME_NONE, PM_SLEEP_SRC_CTW);
        /* read status to clear interrupt register */
        CyPmReadStatus(CY_PM_CTW_INT);
        /* restore the clock-settings */
        CyPmRestoreClocks();
        /* short blink to show that we're not in real hibernate */
        ledToggle();
        CyDelay(50);
        ledToggle();
    } while (hibernateInProgress);

    /* 
    blue light
    what does it do?
    it shines blue
    */
    ledOn();

    componentsWakeup();

    if(modemOn)
    {
        nbiotWakeup();
    }

    /* 
    Synchronize the time after sleep.
    */
    #if( HAS_MODEM_RTC )
    t = getModemTime();
    setTime(t);
    #endif
}

void platformHibernate()
{
#ifdef USBFS_DEVICE        
    #ifdef LINUX_HOST
        fakeHibernateBySleep();
    #else
        fakedHibernate();
    #endif
#else
    psocHibernate();
#endif
    /* we're back from hibernate */
    hibernateInProgress = 0;
}


/* [] END OF FILE */
