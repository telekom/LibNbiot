/* ========================================================================
 * File Name: usb_com.c
 *
 * Author: Edgar Hindemith
 *
 * Copyright (C) 2016,2018, Ingenieurbuero Edgar Hindemith, 
 * T-Systems International GmbH
 * contact: libnbiot@t-systems.com, opensource@telekom.de
 *
 * This file is distributed under the conditions of the Apache License,
 * Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * For details see the file LICENSE at the toplevel.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================================
*/

#include "libnbiotcore.h"
#include "libnbiot.h"
#include "led.h"
#include "usb_com.h"

void startUsb()
{
    /* Start USBFS operation with 5-V operation. */
    USBUART_Start(USBFS_DEVICE, USBUART_5V_OPERATION);
}

void checkUsbConf()
{
    /* Host can send double SET_INTERFACE request. */
    if (0u != USBUART_IsConfigurationChanged())
    {
        /* Initialize IN endpoints when device is configured. */
        if (0u != USBUART_GetConfiguration())
        {
            /* Enumeration is done, enable OUT endpoint to receive data 
             * from host. */
            USBUART_CDC_Init();
        }
    }
}

unsigned char usbReady()
{
    unsigned char ret = 1;
    long long millis = getMillis();
    while (0u == USBUART_CDCIsReady())
    {
        if((getMillis() - millis) > USB_TIMEOUT)
        {
            ret = 0;
            break;
        }
    }
    return ret;
}

void dbgWrite(const uint8* buf, uint16 len)
{
    const uint8* ptr = buf;
    uint16 remaining = len;
    uint16 l = (remaining > USBUART_BUFFER_SIZE) ? USBUART_BUFFER_SIZE : remaining;
    checkUsbConf();
    while(remaining)
    {
        if(usbReady())
        {
            USBUART_PutData(ptr, l);
            if(USBUART_BUFFER_SIZE == l)
            {
                if(usbReady())
                {
                    /* Send zero-length packet to PC. */
                    USBUART_PutData(NULL, 0u);
                }
                else
                {
                    break;
                }
            }
            ptr += l;
            remaining -= l;
            l = (remaining > USBUART_BUFFER_SIZE) ? USBUART_BUFFER_SIZE : remaining;
        }
        else
        {
            break;
        }
    }
}

void usbSleep()
{
    uint8 activity = 1;
    
    do
    {
        activity = USBUART_CheckActivity();
    } while(activity);
    USBUART_Suspend();
}

void usbWakeup()
{
    u_char woMsg[] = {"woke up\r\n"};

    USBUART_Resume();

    USBUART_Force(USBUART_FORCE_SE0);
    CyDelay(5);
    USBUART_Force(USBUART_FORCE_NONE);
    
    /* Restore communication with host for IN and OUT endpoints. 
    */
    if(USBUART_SUCCESS == USBUART_CDC_Init())
    {
        USBUART_PutData(woMsg, strlen((char*)woMsg) + 1);
    }
    /* give the terminal a chance to reconnect
    */
    delay(1000);
}

/* [] END OF FILE */
