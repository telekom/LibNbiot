/* ========================================================================
 * LibNbiot PSoC5 example for CY8C5888LTI-LP097 (CYC8CKIT-059): main.c
 *
 * Copyright (c) 2018, Edgar Hindemith, Yassine Amraue, Thorsten
 * Krautscheid, Kolja Vornholt, T-Systems International GmbH
 * contact: libnbiot@t-systems.com, opensource@telekom.de
 *
 * This file is distributed under the conditions of the Apache License,
 * Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * For details see the file LICENSE at the toplevel.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================================
*/

#include <project.h>
#include <stdarg.h>
#include <unistd.h>
#include "stdio.h"

#include "nbiot_time.h"
#include "usb_com.h"
#include "platform.h"
#include "led.h"
#include "nbiotnotify.h"
#include "nbiotcoreconf.h"
#include "libnbiot.h"
#include "libnbiotcore.h"
#include "auth.h"

#if defined (__GNUC__)
    /* Add an explicit reference to the floating point printf library */
    /* to allow usage of the floating point conversion specifiers. */
    /* This is not linked in by default with the newlib-nano library. */
    asm (".global _printf_float");
#endif

#define TOPIC_BUFFER_SIZE   (64u)
#define PAYLOAD_LENGTH      (12u) /* string size: max int, sign, terminating 0 */

char* state[] = {"Invalid", "Initial", "Disconnected", "Error", "Connected", "Sleep", "Hibernate", "Sleep (DIS)", "Awake", "Wait for modem attach", "Wait for connect"};
char* action[] = {"Initialize", "ReInitialize", "Connect", "RegisterTopic", "Publish", "Subscribe", "Unsubscribe", "RemoveTopic", "Disconnect", "Sleep", "Hibernate", "Wakeup"};
char* retCode[] = {"ACCEPTED", "REJECTED_CONGESTED", "REJECTED_INVALID_TOPIC_ID", "RC_REJECTED_NOT_SUPPORTED"};
char* error[] = {"Ok", "Initializing error", "MODEM not attached", "IP not connected", "Connection error", "Not started error", "MaxTopicsExceeded", "LoopCtrlBusyError", "InvalidTopicID"};


#define MAX_PAYLOAD_LEN 20

int notification_id = 0;
void notificationHandler(const Notification *n)
{
    // Handle your notifications here
    notification_id++;

    debugPrintf("\033[0;32m[ Debug    ]\033[0m ");

    debugPrintf("----- New notification %03d -----\r\n", notification_id);

    debugPrintf("\033[1;34m[----------]\033[0m State: \033[27G");
    debugPrintf("%s\r\n", state[n->state]);

    debugPrintf("\033[1;34m[----------]\033[0m Action: \033[27G");
    debugPrintf("%s\r\n", action[n->action]);

    debugPrintf("\033[1;34m[----------]\033[0m ReturnCode: \033[27G");
    debugPrintf("%s\r\n", retCode[n->returnCode]);

    debugPrintf("\033[1;34m[----------]\033[0m ErrorNumber: \033[27G");
    debugPrintf("%s\r\n", error[n->errorNumber]);

    // blink the LED
    blink(5, 20);
}


unsigned char messageArrived = 0;
int message_counter = 0;
void subscriptionHandler(MessageData* msg)
{
    messageArrived = 1;
    message_counter++;

    debugPrintf("\033[0;32m[ Debug    ]\033[0m ");

    debugPrintf("----- New message %03d -----\r\n", message_counter);

    debugPrintf("\033[0;35m[----------]\033[0m QoS: \033[27G");
    debugPrintf("%d\r\n", msg->message->qos);

    debugPrintf("\033[0;35m[----------]\033[0m Id: \033[27G");
    debugPrintf("%d\r\n", msg->message->id);

    debugPrintf("\033[0;35m[----------]\033[0m Payload: \033[27G");
    debugPrintf("%s\r\n", (char *) msg->message->payload);

    if(msg->topicName)
    {
        debugPrintf("\033[0;35m[----------]\033[0m Topic: \033[27G");
        debugPrintf("%s\r\n", (char *) msg->topicName);
    }
}

unsigned char init(char* imsi, char* pw)
{
    unsigned char ret=0;

    NbiotCoreConf core_conf;
    core_conf.tickFrequency = 1000;
    core_conf.readstatus_fu = readStatus;
    core_conf.readbyte_fu = UART_1_ReadRxData;
    core_conf.putchar_fu = UART_1_PutChar;
    core_conf.writestatus_fu = writeStatus;
    core_conf.apn = "nb-cloud.ic.m2mportal.de";
    core_conf.apnUser = "";
    core_conf.apnPwd = "";
    core_conf.operMccMnc = "26201";
    core_conf.imsi = imsi;
    core_conf.imsiPwd = pw;

    unsigned int retCoreConf = nbiotCoreConfig(&core_conf);

    NbiotConf conf;
    conf.keepAliveInterval = 10000;
    conf.autoPollInterval = 300;
    conf.maxTopicCount = 3;
    conf.gateway = "172.25.102.151";
    conf.port = 1883;
    conf.notify_fu = notificationHandler;
    conf.pollInterval = 10000;

    unsigned int retConf = nbiotConfig(&conf);


    if ((NoError == retConf) && (NoError == (~(CoreWarnApnUser | CoreWarnApnPwd) & retCoreConf)))
    {
        // Setup the statemachine, initialize internal varibles.
        ret = nbiotStart();
    }

    return ret;
}

/*******************************************************************************
* Function Name: main
********************************************************************************
*
* Summary:
*  The main function performs the following actions:
*   1. Waits until VBUS becomes valid and starts the USBFS component which is
*      enumerated as virtual Com port.
*   2. Waits until the device is enumerated by the host.
*   3. Configures and starts the nbIOT statemachine.
*  The following actions are performed inside the main-loop
*   4. Connects to nbIOT gateway (MQTT broker).
*   5. Subscribes topic "downlink command".
*   6. Publishes response on incoming downlink message.
*   7. Publishes die-temperature.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
int main()
{
    int16 value = 0;
    
    CyGlobalIntEnable;
    
    componentsStart();
    
    setDebugWriteFunction(dbgWrite);
    
    delay(10000);

    unsigned char ret = 0;
    ret = init(AUTH_IMSI, AUTH_PWD);
    
    if(1 == ret)
    {
        debugPrintf("\033[0;32m[ Debug    ]\033[0m ");
        debugPrintf("\033[0;32mInit Successfull\033[0m \r\n");
    }
    else
    {
        debugPrintf("\033[0;31m[ Debug    ]\033[0m ");
        debugPrintf("\033[0;31mInit Error\033[0m \r\n");
    }
    
    // Set topics
    char topicCmd[32];
    sprintf (topicCmd, "NBIoT/%s/CMD/MyCmd", getNbiotDeviceId());

    char topicInf[32];
    sprintf(topicInf, "NBIoT/%s/INF/MyCmd", getNbiotDeviceId());

    char topicTemp[32];
    sprintf(topicTemp, "NBIoT/%s/MES/1", getNbiotDeviceId());

    char payload[PAYLOAD_LENGTH];

    enum NbiotResult rc = LC_Pending;

    for(;;)
    {
        if(1 == ret)
        {
            if (isNbiotConnected())
            {
                if (LC_Idle == rc)
                {
                    // If not subscribed already, subscribe to command topic.
                    if(!isNbiotSubscribedTo(topicCmd))
                    {
                        nbiotSubscribe(topicCmd, subscriptionHandler );
                    }

                    if(messageArrived)
                    {
                        nbiotPublish(topicInf, "0", 1, QOS0);
                        messageArrived = 0;
                    }
                    else
                    {
                        DieTemp_1_GetTemp(&value);
                        sprintf(payload, "%d", value);

                        debugPrintf("\033[0;32m[ DEBUG    ]\033[0m ");
                        debugPrintf("Publish: %s\r\n", payload);

                        nbiotPublish(topicTemp, payload, strlen(payload), QOS0);
                    }
                }
            }
            else
            {
                if (LC_Idle == rc)
                {
                    nbiotConnect(1); // Connect with cleanSession=1
                }
            }

            rc = nbiotEventLoop(EventModeActive);
            delay(50);
        }
    }
}


/* [] END OF FILE */
