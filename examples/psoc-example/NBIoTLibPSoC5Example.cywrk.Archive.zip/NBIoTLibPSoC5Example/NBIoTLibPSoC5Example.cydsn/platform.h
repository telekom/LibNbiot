/*========================================================================
 * File Name: platform.h
 *
 * Author: Edgar Hindemith
 *
 * Copyright (C) 2016,2018, Ingenieurbuero Edgar Hindemith, 
 * T-Systems International GmbH
 * contact: libnbiot@t-systems.com, opensource@telekom.de
 *
 * This file is distributed under the conditions of the Apache License,
 * Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * For details see the file LICENSE at the toplevel.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================================
*/
#ifndef _PLATFORM_H
#define _PLATFORM_H

#include <project.h>
#include "readstatus.h"
#include "writestatus.h"

#ifndef HAS_MODEM_RTC
#define HAS_MODEM_RTC 0 /* NO RTC in NBIoT-Modem or its emulation */
#endif
    
#define MILLIS_SLEEP_UPDATE 1024 
#define NBIOT_HIBERNATE_STATE 6

extern uint8 hibernateInProgress;    

CY_ISR_PROTO(wakeupHandler);
CY_ISR_PROTO(buttonHandler);

ReadStatus readStatus();
WriteStatus writeStatus();

void componentsStartEx();
void componentsStart();

void componentsSleepEx();
void componentsSleep();
void componentsWakeupEx();
void componentsWakeup();

void psocSleep(uint32 seconds, uint8 rtcAvail);
void fakedSleep(uint32 s);
void platformSleep(uint32 seconds, uint8 rtcAvail);

void psocHibernate();
void fakedHibernate();
void fakeHibernateBySleep();
void platformHibernate();

#endif /* _PLATFORM_H */
/* [] END OF FILE */
