/* ========================================================================
 * File Name: led.h
 *
 * Author: Edgar Hindemith
 *
 * Copyright (C) 2016,2018, Ingenieurbuero Edgar Hindemith, 
 * T-Systems International GmbH
 * contact: libnbiot@t-systems.com, opensource@telekom.de
 *
 * This file is distributed under the conditions of the Apache License,
 * Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * For details see the file LICENSE at the toplevel.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either expressed or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================================
*/
#ifndef _LED_H
#define _LED_H
    
#include <project.h>

#include "libnbiotcore.h"

#define ON 1
#define OFF 0

void ledOn();
void ledOff();
uint8 led();
void ledToggle();
void blink(unsigned char count, unsigned short ms);

#endif /* _LED_H */
/* [] END OF FILE */
